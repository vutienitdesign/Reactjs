import React, { Component } from 'react';

class Hello extends Component {
    render() {
        return (
            <div >
               <h3>HelloComponent</h3>
            </div>
        );
    }
}

export default Hello;
